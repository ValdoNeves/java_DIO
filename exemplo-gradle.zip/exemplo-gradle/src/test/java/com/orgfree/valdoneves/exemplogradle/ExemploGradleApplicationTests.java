package com.orgfree.valdoneves.exemplogradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
